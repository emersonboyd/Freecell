package cs3500.hw02.model;

/**
 * Represents a color that a playing card can take the form of.
 */
public enum Color {
  RED, BLACK;
}
